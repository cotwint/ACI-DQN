"""src.evaluation -- metrics aggregation and plotting."""
