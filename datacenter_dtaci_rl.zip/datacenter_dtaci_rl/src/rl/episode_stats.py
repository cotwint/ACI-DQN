"""
src/rl/episode_stats.py
-----------------------
A pure-NumPy data container for one episode's summary statistics.
Lives in its own module (no torch import) so that heuristic baselines
which never train a network do not pay the torch dependency cost.
"""

from __future__ import annotations

from dataclasses import dataclass

import numpy as np


@dataclass
class EpisodeStats:
    day_index: int
    total_reward: float
    total_cost: float
    elec_cost: float
    qos_cost: float
    switch_cost: float
    sla_violations: np.ndarray
    completed: np.ndarray
    delay_sum: np.ndarray
    avg_n_active: float
    peak_power: float
    avg_power: float
    energy: float
    avg_util: float
