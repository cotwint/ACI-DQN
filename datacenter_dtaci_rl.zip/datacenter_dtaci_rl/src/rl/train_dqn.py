"""
src/rl/train_dqn.py
-------------------
Generic training and evaluation loops shared by ordinary DQN, ACI-DQN
and DtACI-DQN.

The conformal / shield mechanisms are passed in through a
``StateAugmenter`` callable. This avoids three copies of the same loop.

A ``StateAugmenter`` is any object that exposes::

    reset(env, day_index)                 -> None
    augment(state, env) -> np.ndarray     # state used by the agent
    shield(action, state, env) -> int     # post-process the action
    on_step(env, info, action_pre, action_post) -> None
    metrics() -> dict
"""

from __future__ import annotations

from pathlib import Path
from typing import Callable, Dict, List, Optional

import numpy as np

from ..datacenter_env import DataCenterEnv
from ..utils import get_logger, ensure_dir
from .dqn_agent import DQNAgent
from .episode_stats import EpisodeStats  # re-export so callers can import here


# ---------------------------------------------------------------------------
# Pass-through identity augmenter (= ordinary DQN)
# ---------------------------------------------------------------------------

class IdentityAugmenter:
    name = "identity"

    def reset(self, env, day_index):
        pass

    def augment(self, state, env):
        return state

    def shield(self, action, state, env):
        return action

    def on_step(self, env, info, action_pre, action_post):
        pass

    def metrics(self):
        return {}


# ---------------------------------------------------------------------------
# Episode rollout
# ---------------------------------------------------------------------------

def rollout_episode(env: DataCenterEnv,
                    agent: DQNAgent,
                    augmenter,
                    day_index: int,
                    train: bool,
                    seed: Optional[int] = None) -> EpisodeStats:
    state, _ = env.reset(day_index, seed=seed)
    augmenter.reset(env, day_index)
    s_aug = augmenter.augment(state, env)

    total_reward = 0.0
    while not env.done:
        a_raw = (agent.select_action(s_aug, greedy=not train)
                 if agent is not None else 0)
        a_safe = augmenter.shield(a_raw, s_aug, env)
        next_state, reward, done, info = env.step(a_safe)
        s2_aug = augmenter.augment(next_state, env)
        augmenter.on_step(env, info, a_raw, a_safe)
        if train and agent is not None:
            agent.push(s_aug, a_safe, reward, s2_aug, done)
            agent.train_step()
        s_aug = s2_aug
        total_reward += reward

    h = env.history_as_arrays()
    return EpisodeStats(
        day_index=day_index,
        total_reward=total_reward,
        total_cost=float(h["total_cost"].sum()),
        elec_cost=float(h["elec_cost"].sum()),
        qos_cost=float(h["qos_cost"].sum()),
        switch_cost=float(h["switch_cost"].sum()),
        sla_violations=h["violations"].sum(axis=0),
        completed=h["completed"].sum(axis=0),
        delay_sum=h["delay_sum"].sum(axis=0),
        avg_n_active=float(h["n_active"].mean()),
        peak_power=float(h["facility_power_kw"].max()),
        avg_power=float(h["facility_power_kw"].mean()),
        energy=float(h["energy_kwh"].sum()),
        avg_util=float(h["util"].mean()),
    )


# ---------------------------------------------------------------------------
# Training loop
# ---------------------------------------------------------------------------

def train_agent(env: DataCenterEnv,
                agent: DQNAgent,
                augmenter,
                train_days: List[int],
                episodes: int,
                rng: np.random.Generator,
                log_path: Optional[str] = None) -> Dict[str, List[float]]:
    log = get_logger("rl.train",
                     log_file=str(log_path) if log_path else None)
    history: Dict[str, List[float]] = {"reward": [], "cost": [], "epsilon": []}
    for ep in range(episodes):
        day = int(rng.choice(train_days))
        stats = rollout_episode(env, agent, augmenter,
                                day_index=day, train=True,
                                seed=int(rng.integers(0, 2**31 - 1)))
        agent.decay_epsilon()
        history["reward"].append(stats.total_reward)
        history["cost"].append(stats.total_cost)
        history["epsilon"].append(agent.epsilon)
        if (ep + 1) % max(1, episodes // 10) == 0 or ep == 0:
            log.info(f"  ep {ep+1:4d}/{episodes}  day={day:3d}  "
                     f"reward={stats.total_reward:9.1f}  cost={stats.total_cost:9.1f}  "
                     f"eps={agent.epsilon:.3f}")
    return history


def evaluate(env: DataCenterEnv,
             agent: Optional[DQNAgent],
             augmenter,
             eval_days: List[int],
             rng: Optional[np.random.Generator] = None) -> List[EpisodeStats]:
    rng = rng or np.random.default_rng(0)
    out: List[EpisodeStats] = []
    for d in eval_days:
        stats = rollout_episode(env, agent, augmenter,
                                day_index=int(d),
                                train=False,
                                seed=int(rng.integers(0, 2**31 - 1)))
        out.append(stats)
    return out
