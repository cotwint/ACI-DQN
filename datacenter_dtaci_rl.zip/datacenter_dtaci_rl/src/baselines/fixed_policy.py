"""
src/baselines/fixed_policy.py
-----------------------------
Constant-capacity baseline: always keep the same number of servers on.

By default we use the midpoint between Nmin and Nmax, but this can be
overridden via the ``n_fixed`` constructor argument.
"""

from __future__ import annotations

from typing import Dict, Optional

import numpy as np


class FixedPolicy:
    name = "fixed"

    def __init__(self, cfg: Dict, n_fixed: Optional[int] = None):
        Nmin = int(cfg["server"]["Nmin"])
        Nmax = int(cfg["server"]["Nmax"])
        if n_fixed is None:
            n_fixed = (Nmin + Nmax) // 2
        self.n_fixed = int(np.clip(n_fixed, Nmin, Nmax))
        self.cfg = cfg

    def act(self, state: np.ndarray, env) -> int:
        """Return discrete action index that yields ``n_fixed`` active servers."""
        from ..datacenter_env import n_to_action
        return n_to_action(self.n_fixed, self.cfg)

    def reset(self):
        pass
