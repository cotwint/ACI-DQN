"""
src/baselines/price_aware_greedy_policy.py
------------------------------------------
Python port of the existing Octave ``greedy_policy.m``.

Behaviour:
  * P1 work has 1.20 weight, P2 work 0.80 weight.
  * P3 is deferred (deferrableFactor=0.25) when price is well above its
    daily mean; otherwise weighted at 0.60.
  * Whenever any P3 task has slack <= 4 slots, it is *not* deferred.
  * Near-deadline work (slack <= 25% of D_k) gets an extra 0.80 weight.
  * The result is divided by target utilisation and capped by ramp limits
    and Nmin/Nmax.
"""

from __future__ import annotations

from typing import Dict

import numpy as np


class PriceAwareGreedyPolicy:
    name = "price_aware_greedy"

    def __init__(self, cfg: Dict):
        self.cfg = cfg
        self.Nmin = int(cfg["server"]["Nmin"])
        self.Nmax = int(cfg["server"]["Nmax"])
        self.cap = float(cfg["server"]["cap_per_server"])
        self.target_util = float(cfg["server"]["target_util"])
        self.ramp = int(cfg["server"]["ramp_limit"])
        self.deadlines = np.asarray(cfg["qos"]["deadline_slots"], dtype=int)

    def reset(self):
        pass

    def act(self, state: np.ndarray, env) -> int:
        from ..datacenter_env import n_to_action

        K = env.K
        work = np.zeros(K)
        near_work = np.zeros(K)
        min_slack = np.full(K, np.inf)

        for k in range(K):
            if not env.queues[k]:
                continue
            slacks = np.array([task.deadline - env.t + 1
                              for task in env.queues[k]])
            work[k] = sum(task.remaining for task in env.queues[k])
            min_slack[k] = float(slacks.min())
            near_thresh = max(1, int(np.ceil(0.25 * self.deadlines[k])))
            mask = slacks <= near_thresh
            near_work[k] = sum(task.remaining
                               for task, m in zip(env.queues[k], mask) if m)

        price = float(env.price_curve[env.t])
        price_mean = float(env.price_curve.mean())
        price_std = float(env.price_curve.std())

        if price > price_mean + 0.25 * price_std:
            deferrable = 0.25
        else:
            deferrable = 1.00
        # If P3 is close to its deadline, override and process it.
        if min_slack[2] <= 4:
            deferrable = 1.00

        effective = (1.20 * work[0]
                     + 0.80 * work[1]
                     + deferrable * 0.60 * work[2]
                     + 0.80 * near_work.sum())
        desired_cap = effective / max(0.05, self.target_util)
        n_raw = int(np.ceil(desired_cap / self.cap))
        n_raw = int(np.clip(n_raw, env.n_prev - self.ramp,
                            env.n_prev + self.ramp))
        n_raw = int(np.clip(n_raw, self.Nmin, self.Nmax))
        return n_to_action(n_raw, self.cfg)
