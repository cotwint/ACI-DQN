"""src.safe_layer -- DtACI action shield."""
