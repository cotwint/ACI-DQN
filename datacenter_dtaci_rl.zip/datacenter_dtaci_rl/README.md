# Datacenter Compute–Power Co-optimisation with DtACI-Shielded DQN

A research codebase implementing **DQN + Dynamically-tuned Adaptive Conformal Inference (DtACI)** for joint server-scaling and workload-dispatch in an electricity-market-aware datacenter. The framework is described in detail in `experiment_modeling_section.docx`.

---

## Project layout

```
datacenter_dtaci_rl/
├── config.yaml                  # Single source of truth for all parameters
├── run_all_experiments.py       # Top-level experiment runner
├── requirements.txt
│
├── src/
│   ├── data_preprocess.py       # CSV → cleaned 15-min load, train/cal/test split
│   ├── price_model.py           # Time-of-use electricity price curve (CNY/kWh)
│   ├── workload_generator.py    # Synthetic P1/P2/P3 Poisson task arrivals
│   ├── utils.py                 # Config loading, seeding, logging, RunningStats
│   │
│   ├── conformal/               # DtACI conformal prediction module
│   │   └── __init__.py
│   │
│   ├── rl/
│   │   ├── __init__.py
│   │   └── episode_stats.py     # Per-episode metric accumulator & TrainingHistory
│   │
│   ├── baselines/               # Greedy and other reference policies
│   │   └── __init__.py
│   │
│   ├── safe_layer/              # Action-shield (conformal coverage enforcer)
│   │   └── __init__.py
│   │
│   └── evaluation/              # Plotting and tabular comparison helpers
│       └── __init__.py
│
├── experiments/                 # Callable experiment scripts
│   └── __init__.py
│
└── outputs/                     # Auto-created at runtime
    ├── processed/               # Cleaned CSVs from data_preprocess.py
    ├── figures/                 # Saved plots
    └── logs/                    # Training logs
```

---

## Quick start

### 1. Install dependencies

```bash
pip install -r requirements.txt
```

PyTorch is required for the DQN agent. CPU-only is sufficient for
experiments at this scale.

### 2. Place the data

Put `区域负荷2020-2023数据.csv` in the **project root** (same directory as
`config.yaml`). The file is already referenced there by default.

### 3. Run everything

```bash
python run_all_experiments.py --config config.yaml
```

This executes, in order:

| Stage | What happens |
|---|---|
| **Preprocess** | Cleans the raw regional-load CSV to a 15-min grid; splits chronologically into 60 % train / 20 % calibration / 20 % test. |
| **Greedy baseline** | Runs the rule-based dispatch policy (mirrors `greedy_policy.m`) on every test day; records cost, SLA violation rate, utilisation. |
| **DQN training** | Trains the DQN agent on training days for `rl.train_episodes` episodes with ε-greedy exploration. |
| **DtACI calibration** | Fits the DtACI mixture-of-experts conformal predictor on calibration days; exports coverage quantiles used by the action shield. |
| **DQN + shield evaluation** | Evaluates the trained agent with the action shield active on test days. |
| **Reporting** | Writes summary tables and figures to `outputs/`. |

---

## Model overview

### Environment

The datacenter operates over a day divided into **T = 96 slots** (Δt = 15 min). At each slot the agent chooses the number of active servers n ∈ [N_min, N_max]. Three priority classes of tasks (P1 urgent, P2 interactive, P3 batch) arrive according to a Poisson process whose rate is driven by the normalised regional load curve x(t).

The per-slot cost is:

$$c_t = \underbrace{E_t \cdot \pi_t}_{\text{energy}} + \underbrace{\sum_k \beta_k v_{k,t} + \rho_k o_{k,t}}_{\text{SLA}} + \underbrace{\phi \,|\Delta n_t|}_{\text{switching}}$$

where E_t is facility energy (kWh), π_t is the time-of-use price (CNY/kWh),
β_k / ρ_k are per-priority SLA penalties and overdue-pending penalties, and φ is the server-switch cost.

### Conformal action shield (DtACI)

Before each action is passed to the environment, the **safe layer** uses a
DtACI workload forecaster to compute a conformal prediction interval for
future queue depth. If the proposed action would violate coverage for
priorities P1/P2 (`conformal.protect_priorities`), the shield clips the
action upward to the minimum safe server count.

DtACI maintains a mixture of η-experts and adapts the effective coverage level α(t) online, providing finite-sample marginal coverage guarantees even under distribution shift.

### DQN agent

- **State** s_t: slot index, normalised load x_t, active servers, per-priority queue lengths and backlog work, current price tier.
- **Action** a_t: discrete bin in [N_min, N_max] (21 bins by default).
- **Reward** r_t = −reward_scale × c_t.
- Standard experience-replay DQN with target network updated every `target_update_interval` gradient steps.

---

## Key configuration knobs (`config.yaml`)

| Key | Default | Description |
|---|---|---|
| `rl.train_episodes` | 300 | Training episodes |
| `rl.eval_episodes` | 50 | Evaluation episodes |
| `rl.action_bins` | 21 | Server count discretisation |
| `conformal.alpha` | 0.10 | Target marginal miscoverage |
| `conformal.dtaci_etas` | [0.005, 0.02, 0.05, 0.1, 0.25] | Expert learning rates |
| `conformal.protect_priorities` | [1, 2] | Priorities shielded (K′) |
| `qos.sla_penalty` | [20, 8, 2] | β_k per violation (CNY-equivalent) |
| `seed` | 2024 | Global random seed |

---

## Reproducing the paper results

All random seeds, hyperparameters and data splits are fixed in `config.yaml`.
Running `run_all_experiments.py` end-to-end will reproduce the tables in
`experiment_modeling_section.docx` up to floating-point non-determinism on
different hardware.

---

## Reference

This implementation accompanies the paper/report:

> *Adaptive Conformal Inference-Shielded Deep Q-Network for Compute–Power
> Co-optimisation in Electricity-Market-Aware Datacenters* (2024).

The regional load data (`区域负荷2020-2023数据.csv`) is used **only** to
derive diurnal load-shape proxies for synthetic workload generation; it is
not a real datacenter trace.
