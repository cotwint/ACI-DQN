"""
run_all_experiments.py
======================
Top-level orchestrator for the datacenter DtACI-DQN co-optimisation study.

Stages
------
1. Preprocess raw regional load CSV
2. Greedy baseline evaluation (mirrors greedy_policy.m / simulate_datacenter.m)
3. DQN agent training
4. DtACI conformal predictor calibration
5. DQN + action-shield evaluation on test days
6. Summary reporting

All hyper-parameters are read from ``config.yaml`` (or --config path).

Usage
-----
    python run_all_experiments.py                       # uses config.yaml
    python run_all_experiments.py --config my_cfg.yaml
    python run_all_experiments.py --stages preprocess greedy  # subset
    python run_all_experiments.py --seed 42 --verbose
"""

from __future__ import annotations

import argparse
import json
import sys
import time
from pathlib import Path
from typing import Dict, List, Optional

import numpy as np

# ---------------------------------------------------------------------------
# Resolve project root so the script can be run from any cwd
# ---------------------------------------------------------------------------
_ROOT = Path(__file__).parent.resolve()
sys.path.insert(0, str(_ROOT))

from src.utils import ensure_dir, get_logger, load_config, set_global_seed
from src.data_preprocess import (
    load_processed,
    normalised_day_matrix,
    run as preprocess_run,
)
from src.price_model import build_daily_price
from src.workload_generator import generate_day
from src.rl.episode_stats import EpisodeStats, TrainingHistory


# ---------------------------------------------------------------------------
# Minimal datacenter step (Python replica of simulate_datacenter.m)
# ---------------------------------------------------------------------------

def _tou_price_index(slot: int, cfg: Dict) -> float:
    """Return CNY/kWh price for a given 15-min slot."""
    hour = slot // 4
    if hour in cfg["price"]["high_hours"]:
        return cfg["price"]["high"]
    if hour in cfg["price"]["middle_hours"]:
        return cfg["price"]["middle"]
    return cfg["price"]["low"]


class DatacenterEnv:
    """Lightweight gym-like environment wrapping the discrete-time datacenter.

    This mirrors ``simulate_datacenter.m`` without pulling in the full
    MATLAB toolchain.  The RL agent interacts via ``reset`` / ``step``.

    Parameters
    ----------
    cfg : dict  Full config dict (loaded from config.yaml).
    day_load : np.ndarray  Shape (T,) normalised load curve x(t) ∈ [0,1].
    seed : int  Reproducibility seed for workload generation.
    """

    def __init__(self, cfg: Dict, day_load: np.ndarray, seed: int = 0) -> None:
        self.cfg = cfg
        self.day_load = day_load
        self.seed = seed

        T = cfg["time"]["slots_per_day"]
        K = cfg["qos"]["K"]
        self.T = T
        self.K = K

        # Derived constants
        self.Nmin = cfg["server"]["Nmin"]
        self.Nmax = cfg["server"]["Nmax"]
        self.cap = cfg["server"]["cap_per_server"]
        self.P_idle = cfg["power"]["P_idle"]
        self.P_peak = cfg["power"]["P_peak"]
        self.P_fixed = cfg["power"]["P_fixed"]
        self.PUE = cfg["power"]["PUE"]
        self.gamma = cfg["power"]["power_gamma"]
        self.switch_cost = cfg["power"]["switch_cost"]
        self.dt = cfg["time"]["dt_hour"]
        self.sla_pen = np.asarray(cfg["qos"]["sla_penalty"], dtype=np.float64)
        self.overdue_pen = np.asarray(cfg["qos"]["overdue_penalty"], dtype=np.float64)
        self.deadlines = np.asarray(cfg["qos"]["deadline_slots"], dtype=int)
        self.mu = np.asarray(cfg["qos"]["service_mean"], dtype=np.float64)
        self.sd = np.asarray(cfg["qos"]["service_std"], dtype=np.float64)

        self._price = build_daily_price(cfg)
        self._workload = None
        self._t = 0
        self._n_prev = self.Nmin
        # Queue: list of K lists of [remaining_work, arrival, deadline]
        self._queues: List[List[List[float]]] = [[] for _ in range(K)]

    # ------------------------------------------------------------------
    def reset(self, day_load: Optional[np.ndarray] = None,
              seed: Optional[int] = None) -> np.ndarray:
        """Reset to a new episode. Returns the initial observation."""
        if day_load is not None:
            self.day_load = day_load
        if seed is not None:
            self.seed = seed

        self._t = 0
        self._n_prev = self.Nmin
        self._queues = [[] for _ in range(self.K)]
        self._workload = generate_day(self.day_load, self.cfg, seed=self.seed)
        return self._observe()

    # ------------------------------------------------------------------
    def step(self, action: int):
        """Advance one time-slot with *action* active servers.

        Returns
        -------
        obs : np.ndarray  Next observation.
        reward : float
        done : bool
        info : dict  Detailed cost breakdown and QoS metrics.
        """
        t = self._t
        n = int(np.clip(action, self.Nmin, self.Nmax))

        # --- Arrivals ---------------------------------------------------
        for k in range(self.K):
            for task in self._workload.tasks_per_slot[k][t]:
                self._queues[k].append(
                    [task.remaining, task.arrival, task.deadline]
                )

        # --- Dispatch (EDF within priority) ----------------------------
        cap_left = float(n * self.cap)
        served_work = np.zeros(self.K)
        completed = np.zeros(self.K, dtype=int)
        violations = np.zeros(self.K, dtype=int)

        for k in range(self.K):
            if cap_left <= 1e-12 or not self._queues[k]:
                continue
            # Sort by deadline ascending (EDF)
            self._queues[k].sort(key=lambda x: x[2])
            remaining_queue = []
            for task in self._queues[k]:
                if cap_left <= 1e-12:
                    remaining_queue.append(task)
                    continue
                served = min(cap_left, task[0])
                task[0] -= served
                cap_left -= served
                served_work[k] += served
                if task[0] <= 1e-9:
                    completed[k] += 1
                    if t > task[2]:
                        violations[k] += 1
                else:
                    remaining_queue.append(task)
            self._queues[k] = remaining_queue

        # --- Overdue pending -------------------------------------------
        overdue_pending = np.array([
            sum(1 for task in self._queues[k] if t > task[2])
            for k in range(self.K)
        ], dtype=int)

        # --- Power & costs --------------------------------------------
        capacity = n * self.cap
        total_served = float(served_work.sum())
        util = min(1.0, total_served / capacity) if capacity > 0 else 0.0

        it_power = (n * (self.P_idle + (self.P_peak - self.P_idle)
                    * (util ** self.gamma)) + self.P_fixed)
        facility_power = self.PUE * it_power
        energy_kwh = facility_power * self.dt
        energy_cost = energy_kwh * self._price[t]

        sla_cost = float(
            np.dot(self.sla_pen, violations)
            + np.dot(self.overdue_pen, overdue_pending)
        )
        switching_cost = self.switch_cost * abs(n - self._n_prev)
        total_cost = energy_cost + sla_cost + switching_cost

        # --- Queue depth for observation ------------------------------
        queue_len = np.array([len(q) for q in self._queues], dtype=np.float32)
        backlog = np.array(
            [sum(task[0] for task in q) for q in self._queues],
            dtype=np.float32,
        )

        self._n_prev = n
        self._t += 1
        done = self._t >= self.T

        info = dict(
            active=n, util=util,
            it_power_kw=it_power, facility_power_kw=facility_power,
            energy_kwh=energy_kwh, energy_cost=energy_cost,
            sla_cost=sla_cost, switching_cost=switching_cost,
            total_cost=total_cost,
            completed=completed, violations=violations,
            queue_len=queue_len.astype(int),
            backlog_work=backlog,
            overdue_pending=overdue_pending,
        )
        reward = -self.cfg["rl"]["reward_scale"] * total_cost
        return self._observe(), reward, done, info

    # ------------------------------------------------------------------
    def _observe(self) -> np.ndarray:
        t = min(self._t, self.T - 1)
        slot_norm = t / (self.T - 1)
        price_norm = self._price[t] / self.cfg["price"]["high"]
        n_norm = (self._n_prev - self.Nmin) / max(1, self.Nmax - self.Nmin)
        load_val = float(self.day_load[t])

        queue_len = np.array([len(q) for q in self._queues], dtype=np.float32)
        backlog = np.array(
            [sum(task[0] for task in q) for q in self._queues],
            dtype=np.float32,
        )
        # Normalise queue lengths loosely
        ql_norm = np.clip(queue_len / 20.0, 0.0, 5.0)
        bl_norm = np.clip(backlog / 50.0, 0.0, 5.0)

        obs = np.concatenate([
            [slot_norm, price_norm, n_norm, load_val],
            ql_norm, bl_norm,
        ], dtype=np.float32)
        return obs

    @property
    def obs_dim(self) -> int:
        return 4 + 2 * self.K

    @property
    def n_actions(self) -> int:
        return self.cfg["rl"]["action_bins"]

    def action_to_n(self, action: int) -> int:
        """Map discrete action index → number of servers."""
        bins = self.cfg["rl"]["action_bins"]
        return int(round(
            self.Nmin + action * (self.Nmax - self.Nmin) / (bins - 1)
        ))


# ---------------------------------------------------------------------------
# Greedy baseline (mirrors greedy_policy.m logic)
# ---------------------------------------------------------------------------

def greedy_server_count(queue_len: np.ndarray, cfg: Dict, t: int,
                        n_prev: int) -> int:
    """Rule-based server selection replicating ``greedy_policy.m``.

    Increases servers when any P1 queue is non-empty, targets utilisation
    ``target_util``, and respects ``ramp_limit``.
    """
    K = cfg["qos"]["K"]
    Nmin = cfg["server"]["Nmin"]
    Nmax = cfg["server"]["Nmax"]
    ramp = cfg["server"]["ramp_limit"]
    target = cfg["server"]["target_util"]
    cap = cfg["server"]["cap_per_server"]

    total_backlog = float(sum(queue_len))
    # Target servers that would reach target utilisation given current backlog
    n_target = int(np.ceil(total_backlog / (target * cap + 1e-9)))
    # P1 urgency override: ensure at least Nmin+4 when P1 queue is non-empty
    if queue_len[0] > 0:
        n_target = max(n_target, Nmin + 4)

    n_target = int(np.clip(n_target, Nmin, Nmax))
    # Ramp-rate constraint
    n = int(np.clip(n_target, n_prev - ramp, n_prev + ramp))
    n = int(np.clip(n, Nmin, Nmax))
    return n


def run_greedy(env: DatacenterEnv, cfg: Dict, stats: EpisodeStats) -> Dict:
    """Run one episode under the greedy policy."""
    obs = env.reset()
    stats.reset()
    done = False
    queue_len_prev = np.zeros(cfg["qos"]["K"])

    while not done:
        t = env._t
        n = greedy_server_count(queue_len_prev, cfg, t, env._n_prev)
        action = round((n - env.Nmin) * (env.n_actions - 1)
                       / max(1, env.Nmax - env.Nmin))
        obs, reward, done, info = env.step(action)
        stats.step(
            t=t, active=info["active"], util=info["util"],
            it_power_kw=info["it_power_kw"],
            facility_power_kw=info["facility_power_kw"],
            energy_kwh=info["energy_kwh"],
            energy_cost=info["energy_cost"],
            sla_cost=info["sla_cost"],
            switching_cost=info["switching_cost"],
            completed=info["completed"],
            violations=info["violations"],
            queue_len=info["queue_len"],
            backlog_work=info["backlog_work"],
            overdue_pending=info["overdue_pending"],
        )
        queue_len_prev = info["queue_len"].astype(float)

    return stats.summarise()


# ---------------------------------------------------------------------------
# DQN agent (minimal tabular-free implementation)
# ---------------------------------------------------------------------------

def _build_dqn(obs_dim: int, n_actions: int, hidden: List[int],
               device: str = "cpu"):
    """Construct a simple MLP DQN network."""
    try:
        import torch
        import torch.nn as nn

        layers = []
        in_dim = obs_dim
        for h in hidden:
            layers += [nn.Linear(in_dim, h), nn.ReLU()]
            in_dim = h
        layers.append(nn.Linear(in_dim, n_actions))
        net = nn.Sequential(*layers).to(device)
        return net
    except ImportError:
        return None


def train_dqn(cfg: Dict, train_days: np.ndarray,
              log, seed: int = 2024) -> Optional[object]:
    """Train a DQN agent.  Returns the trained network or None if PyTorch
    is unavailable (in which case only the greedy baseline runs).

    Parameters
    ----------
    cfg : dict
    train_days : (D, T) normalised load matrix for training days.
    log : logger
    seed : int

    Returns
    -------
    net : torch.nn.Module | None
    history : TrainingHistory
    """
    history = TrainingHistory()
    set_global_seed(seed)

    try:
        import torch
        import torch.nn as nn
        import torch.optim as optim
        from collections import deque
        import random as _random
    except ImportError:
        log.warning("PyTorch not found – skipping DQN training.")
        return None, history

    device = "cuda" if torch.cuda.is_available() else "cpu"
    log.info(f"DQN training on device: {device}")

    rl_cfg = cfg["rl"]
    obs_dim = 4 + 2 * cfg["qos"]["K"]
    n_actions = rl_cfg["action_bins"]
    hidden = rl_cfg["hidden_sizes"]

    online_net = _build_dqn(obs_dim, n_actions, hidden, device)
    target_net = _build_dqn(obs_dim, n_actions, hidden, device)
    target_net.load_state_dict(online_net.state_dict())
    target_net.eval()

    optimiser = optim.Adam(online_net.parameters(), lr=rl_cfg["lr"])
    replay = deque(maxlen=rl_cfg["replay_size"])
    epsilon = rl_cfg["epsilon_start"]
    eps_end = rl_cfg["epsilon_end"]
    eps_decay = rl_cfg["epsilon_decay"]
    gamma = rl_cfg["gamma"]
    batch_sz = rl_cfg["batch_size"]
    warmup = rl_cfg["warmup_steps"]
    tui = rl_cfg["target_update_interval"]
    max_grad = rl_cfg["max_grad_norm"]

    env = DatacenterEnv(cfg, train_days[0], seed=seed)
    stats = EpisodeStats(K=cfg["qos"]["K"],
                         reward_scale=rl_cfg["reward_scale"])
    grad_steps = 0
    D = len(train_days)

    for ep in range(rl_cfg["train_episodes"]):
        day_idx = ep % D
        obs = env.reset(day_load=train_days[day_idx],
                        seed=seed + ep)
        stats.reset()
        done = False
        ep_loss = []

        while not done:
            t = env._t
            # ε-greedy
            if _random.random() < epsilon or grad_steps < warmup:
                action = _random.randrange(n_actions)
            else:
                with torch.no_grad():
                    obs_t = torch.tensor(obs, dtype=torch.float32,
                                         device=device).unsqueeze(0)
                    action = int(online_net(obs_t).argmax(dim=1).item())

            next_obs, reward, done, info = env.step(env.action_to_n(action))
            stats.step(
                t=t, active=info["active"], util=info["util"],
                it_power_kw=info["it_power_kw"],
                facility_power_kw=info["facility_power_kw"],
                energy_kwh=info["energy_kwh"],
                energy_cost=info["energy_cost"],
                sla_cost=info["sla_cost"],
                switching_cost=info["switching_cost"],
                completed=info["completed"],
                violations=info["violations"],
                queue_len=info["queue_len"],
                backlog_work=info["backlog_work"],
                overdue_pending=info["overdue_pending"],
            )
            replay.append((obs, action, reward, next_obs, float(done)))
            obs = next_obs

            # Training step
            if len(replay) >= batch_sz and grad_steps >= warmup:
                batch = _random.sample(replay, batch_sz)
                obs_b, act_b, rew_b, nobs_b, done_b = zip(*batch)
                obs_b = torch.tensor(np.array(obs_b), dtype=torch.float32,
                                     device=device)
                act_b = torch.tensor(act_b, dtype=torch.long,
                                     device=device).unsqueeze(1)
                rew_b = torch.tensor(rew_b, dtype=torch.float32,
                                     device=device)
                nobs_b = torch.tensor(np.array(nobs_b), dtype=torch.float32,
                                      device=device)
                done_b = torch.tensor(done_b, dtype=torch.float32,
                                      device=device)

                q_curr = online_net(obs_b).gather(1, act_b).squeeze(1)
                with torch.no_grad():
                    q_next = target_net(nobs_b).max(dim=1).values
                    q_target = rew_b + gamma * q_next * (1.0 - done_b)

                loss = nn.functional.smooth_l1_loss(q_curr, q_target)
                optimiser.zero_grad()
                loss.backward()
                nn.utils.clip_grad_norm_(online_net.parameters(), max_grad)
                optimiser.step()
                ep_loss.append(loss.item())
                grad_steps += 1

                if grad_steps % tui == 0:
                    target_net.load_state_dict(online_net.state_dict())

        epsilon = max(eps_end, epsilon * eps_decay)
        history.record(ep, stats, extra={
            "epsilon": epsilon,
            "avg_loss": float(np.mean(ep_loss)) if ep_loss else 0.0,
        })

        if (ep + 1) % 50 == 0:
            s = history.latest
            log.info(
                f"  ep {ep+1:4d} | reward {s['total_reward']:+.1f} | "
                f"cost {s['total_cost']:.1f} | "
                f"viol_p1 {s['violation_rate_p1']:.3f} | ε {epsilon:.3f}"
            )

    return online_net, history


# ---------------------------------------------------------------------------
# Evaluation helper
# ---------------------------------------------------------------------------

def evaluate_policy(env: DatacenterEnv, cfg: Dict,
                    test_days: np.ndarray,
                    net=None, n_episodes: int = 50,
                    seed: int = 2024, log=None) -> List[Dict]:
    """Evaluate a policy (DQN net or greedy if net is None) on test days."""
    try:
        import torch
    except ImportError:
        torch = None

    results = []
    stats = EpisodeStats(K=cfg["qos"]["K"],
                         reward_scale=cfg["rl"]["reward_scale"])
    D = len(test_days)

    for ep in range(n_episodes):
        day_idx = ep % D
        obs = env.reset(day_load=test_days[day_idx], seed=seed + ep)
        stats.reset()
        done = False
        queue_len_prev = np.zeros(cfg["qos"]["K"])

        while not done:
            t = env._t
            if net is not None and torch is not None:
                device = next(net.parameters()).device
                with torch.no_grad():
                    obs_t = torch.tensor(obs, dtype=torch.float32,
                                         device=device).unsqueeze(0)
                    action = int(net(obs_t).argmax(dim=1).item())
                n = env.action_to_n(action)
            else:
                n = greedy_server_count(queue_len_prev, cfg, t, env._n_prev)
                action = round((n - env.Nmin) * (env.n_actions - 1)
                               / max(1, env.Nmax - env.Nmin))

            obs, reward, done, info = env.step(n if net else
                                               env.action_to_n(action))
            stats.step(
                t=t, active=info["active"], util=info["util"],
                it_power_kw=info["it_power_kw"],
                facility_power_kw=info["facility_power_kw"],
                energy_kwh=info["energy_kwh"],
                energy_cost=info["energy_cost"],
                sla_cost=info["sla_cost"],
                switching_cost=info["switching_cost"],
                completed=info["completed"],
                violations=info["violations"],
                queue_len=info["queue_len"],
                backlog_work=info["backlog_work"],
                overdue_pending=info["overdue_pending"],
            )
            queue_len_prev = info["queue_len"].astype(float)

        results.append(stats.summarise())

    return results


# ---------------------------------------------------------------------------
# Stage functions
# ---------------------------------------------------------------------------

def stage_preprocess(cfg: Dict, log) -> None:
    log.info("=" * 60)
    log.info("STAGE 1: Data preprocessing")
    log.info("=" * 60)
    preprocess_run(cfg)
    log.info("Preprocessing complete.")


def stage_greedy(cfg: Dict, log, seed: int) -> List[Dict]:
    log.info("=" * 60)
    log.info("STAGE 2: Greedy baseline evaluation")
    log.info("=" * 60)

    load_df, split_df = load_processed(cfg)
    test_dates = set(split_df.loc[split_df["split"] == "test", "date"])
    test_load = load_df[load_df["date"].isin(test_dates)]
    norm_matrix, dates = normalised_day_matrix(
        test_load, cfg["time"]["slots_per_day"]
    )
    log.info(f"  Test days: {len(norm_matrix)}")

    env = DatacenterEnv(cfg, norm_matrix[0], seed=seed)
    stats = EpisodeStats(K=cfg["qos"]["K"],
                         reward_scale=cfg["rl"]["reward_scale"])
    results = []
    for i, day_load in enumerate(norm_matrix):
        env.reset(day_load=day_load, seed=seed + i)
        r = run_greedy(env, cfg, stats)
        results.append(r)

    avg_cost = np.mean([r["total_cost"] for r in results])
    avg_viol = np.mean([r["violation_rate_p1"] for r in results])
    log.info(f"  Greedy  avg_cost={avg_cost:.2f}  viol_p1={avg_viol:.4f}")
    return results


def stage_train_dqn(cfg: Dict, log, seed: int):
    log.info("=" * 60)
    log.info("STAGE 3: DQN training")
    log.info("=" * 60)

    load_df, split_df = load_processed(cfg)
    train_dates = set(split_df.loc[split_df["split"] == "train", "date"])
    train_load = load_df[load_df["date"].isin(train_dates)]
    norm_matrix, _ = normalised_day_matrix(
        train_load, cfg["time"]["slots_per_day"]
    )
    log.info(f"  Train days: {len(norm_matrix)}")

    net, history = train_dqn(cfg, norm_matrix, log, seed=seed)

    out_dir = ensure_dir(cfg["paths"]["outputs_dir"])
    hist_df = history.to_dataframe()
    hist_path = out_dir / "dqn_training_history.csv"
    hist_df.to_csv(hist_path, index=False)
    log.info(f"  Training history saved → {hist_path}")

    if net is not None:
        try:
            import torch
            model_path = out_dir / "dqn_model.pt"
            torch.save(net.state_dict(), model_path)
            log.info(f"  Model saved → {model_path}")
        except Exception as e:
            log.warning(f"  Could not save model: {e}")
    return net


def stage_evaluate(cfg: Dict, log, net, seed: int) -> List[Dict]:
    log.info("=" * 60)
    log.info("STAGE 4: DQN evaluation on test days")
    log.info("=" * 60)

    load_df, split_df = load_processed(cfg)
    test_dates = set(split_df.loc[split_df["split"] == "test", "date"])
    test_load = load_df[load_df["date"].isin(test_dates)]
    norm_matrix, _ = normalised_day_matrix(
        test_load, cfg["time"]["slots_per_day"]
    )
    log.info(f"  Test days: {len(norm_matrix)}")

    env = DatacenterEnv(cfg, norm_matrix[0], seed=seed)
    n_eval = cfg["rl"]["eval_episodes"]
    results = evaluate_policy(env, cfg, norm_matrix, net=net,
                              n_episodes=n_eval, seed=seed, log=log)
    avg_cost = np.mean([r["total_cost"] for r in results])
    avg_viol = np.mean([r["violation_rate_p1"] for r in results])
    log.info(f"  DQN     avg_cost={avg_cost:.2f}  viol_p1={avg_viol:.4f}")
    return results


def stage_report(cfg: Dict, log,
                 greedy_results: List[Dict],
                 dqn_results: Optional[List[Dict]]) -> None:
    log.info("=" * 60)
    log.info("STAGE 5: Summary report")
    log.info("=" * 60)

    import pandas as pd

    out_dir = ensure_dir(cfg["paths"]["outputs_dir"])
    rows = []
    for r in greedy_results:
        r2 = dict(r)
        r2["policy"] = "greedy"
        rows.append(r2)
    if dqn_results:
        for r in dqn_results:
            r2 = dict(r)
            r2["policy"] = "dqn"
            rows.append(r2)

    df = pd.DataFrame(rows)
    report_path = out_dir / "experiment_summary.csv"
    df.to_csv(report_path, index=False)
    log.info(f"  Full results → {report_path}")

    # Print comparison table
    metrics = ["total_cost", "total_energy_cost", "total_sla_cost",
               "avg_utilization", "violation_rate_p1"]
    summary = (
        df.groupby("policy")[metrics]
        .mean()
        .rename(columns={
            "total_cost": "avg_total_cost",
            "total_energy_cost": "avg_energy_cost",
            "total_sla_cost": "avg_sla_cost",
            "avg_utilization": "avg_util",
            "violation_rate_p1": "viol_rate_p1",
        })
    )
    log.info("\n" + summary.to_string())


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

ALL_STAGES = ["preprocess", "greedy", "dqn", "evaluate", "report"]


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Run datacenter DtACI-DQN experiments end-to-end."
    )
    parser.add_argument("--config", default="config.yaml",
                        help="Path to YAML config (default: config.yaml)")
    parser.add_argument("--stages", nargs="+", choices=ALL_STAGES,
                        default=ALL_STAGES,
                        help="Subset of stages to run (default: all)")
    parser.add_argument("--seed", type=int, default=None,
                        help="Override global random seed")
    parser.add_argument("--verbose", action="store_true",
                        help="Extra verbosity")
    return parser.parse_args()


def main() -> None:
    args = parse_args()

    cfg = load_config(args.config)
    seed = args.seed if args.seed is not None else cfg.get("seed", 2024)
    set_global_seed(seed)

    log_dir = ensure_dir(cfg["paths"]["logs_dir"])
    log = get_logger("run_all", log_file=str(log_dir / "run_all.log"))
    log.info(f"Config  : {args.config}")
    log.info(f"Stages  : {args.stages}")
    log.info(f"Seed    : {seed}")

    t0 = time.time()
    greedy_results, dqn_results, net = [], None, None

    if "preprocess" in args.stages:
        stage_preprocess(cfg, log)

    if "greedy" in args.stages:
        greedy_results = stage_greedy(cfg, log, seed)

    if "dqn" in args.stages:
        net = stage_train_dqn(cfg, log, seed)

    if "evaluate" in args.stages:
        dqn_results = stage_evaluate(cfg, log, net, seed)

    if "report" in args.stages:
        stage_report(cfg, log, greedy_results, dqn_results)

    elapsed = time.time() - t0
    log.info(f"\nAll stages done in {elapsed:.1f}s.")


if __name__ == "__main__":
    main()
